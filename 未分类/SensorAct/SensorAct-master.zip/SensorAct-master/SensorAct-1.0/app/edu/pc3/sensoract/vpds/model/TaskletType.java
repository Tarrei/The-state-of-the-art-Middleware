/**
 * 
 */
package edu.pc3.sensoract.vpds.model;

/**
 * @author samy
 *
 */
public enum TaskletType {
	ONESHOT, PERIODIC, EVENT, PERIODIC_AND_EVENT
}
